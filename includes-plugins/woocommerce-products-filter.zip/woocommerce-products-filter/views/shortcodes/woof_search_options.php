<?php if (!defined('ABSPATH')) die('No direct access allowed'); ?>

<div class="woof_products_top_panel_content">
    <?php do_action('woof_products_top_panel_content') ?>
</div>
<div class="woof_products_top_panel"></div>
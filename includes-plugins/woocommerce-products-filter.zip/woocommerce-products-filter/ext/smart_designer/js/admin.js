function woof_checkbox_process_data(x, y) {
    //just plug to admin side to avoid error
}

function woof_radio_direct_search(x, y, z) {
    //just plug to admin side to avoid error
    /*
     if (typeof y === 'object') {
     //checkbox as radio in template, fix     
     document.getElementById('sd-visor').querySelectorAll('input[type="checkbox"]').forEach(item => {
     if (y !== item) {
     item.removeAttribute('checked');
     }
     });
     }
     * 
     */
}


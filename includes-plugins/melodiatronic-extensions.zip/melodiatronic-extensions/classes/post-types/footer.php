<?php
/**
 * Footer manager for Melodiatronic Extensions
 *
 * @package    melodiatronic-extensions
 * @author     Ibnu Sina
 * @license    GNU General Public License, version 3
 * @copyright  2023 Melodiatronic Extensions
 */
 
if ( ! defined( 'ABSPATH' ) ) {
  exit;
}

class Melodiatronic_PostType_Footer {

  	public static function init() {
    	add_action( 'init', array( __CLASS__, 'register_post_type' ) );
    	add_action( 'init', array( __CLASS__, 'register_footer_vc' ) );
    	add_action( 'admin_init', array( __CLASS__, 'add_role_caps' ) );
  	}

  	public static function register_post_type() {
	    $labels = array(
			'name'                  => __( 'Footer Builder', 'melodiatronic-extensions' ),
			'singular_name'         => __( 'Footer', 'melodiatronic-extensions' ),
			'add_new'               => __( 'Add New Footer', 'melodiatronic-extensions' ),
			'add_new_item'          => __( 'Add New Footer', 'melodiatronic-extensions' ),
			'edit_item'             => __( 'Edit Footer', 'melodiatronic-extensions' ),
			'new_item'              => __( 'New Footer', 'melodiatronic-extensions' ),
			'all_items'             => __( 'Footer Builder', 'melodiatronic-extensions' ),
			'view_item'             => __( 'View Footer', 'melodiatronic-extensions' ),
			'search_items'          => __( 'Search Footer', 'melodiatronic-extensions' ),
			'not_found'             => __( 'No Footers found', 'melodiatronic-extensions' ),
			'not_found_in_trash'    => __( 'No Footers found in Trash', 'melodiatronic-extensions' ),
			'parent_item_colon'     => '',
			'menu_name'             => __( 'Footer Builder', 'melodiatronic-extensions' ),
	    );

	    $type = 'melodiatronic_footer';

	    register_post_type( $type,
	      	array(
		        'labels'            => apply_filters( 'melodiatronic_postype_footer_labels' , $labels ),
		        'supports'          => array( 'title', 'editor' ),
		        'public'            => true,
		        'has_archive'       => false,
		        'menu_icon' 		=> 'dashicons-welcome-widgets-menus',
		        'menu_position'     => 51,
				'capability_type'   => array($type,'{$type}s'),
				'map_meta_cap'      => true,	      	
			)
	    );

  	}

  	public static function add_role_caps() {
 
		 // Add the roles you'd like to administer the custom post types
		 $roles = array('administrator');

		 $type  = 'melodiatronic_footer';
		 
		 // Loop through each role and assign capabilities
		 foreach($roles as $the_role) { 
		 
		    $role = get_role($the_role);
		 
			$role->add_cap( 'read' );
			$role->add_cap( 'read_{$type}');
			$role->add_cap( 'read_private_{$type}s' );
			$role->add_cap( 'edit_{$type}' );
			$role->add_cap( 'edit_{$type}s' );
			$role->add_cap( 'edit_others_{$type}s' );
			$role->add_cap( 'edit_published_{$type}s' );
			$role->add_cap( 'publish_{$type}s' );
			$role->add_cap( 'delete_others_{$type}s' );
			$role->add_cap( 'delete_private_{$type}s' ); 
			$role->add_cap( 'delete_published_{$type}s' );
		 
		 }
	}
 

  	public static function register_footer_vc() {
	    $options = get_option('wpb_js_content_types');
	    if ( is_array($options) && !in_array('melodiatronic_footer', $options) ) {
	      	$options[] = 'melodiatronic_footer';
	      	update_option( 'wpb_js_content_types', $options );
	    }
  	}
  
}

Melodiatronic_PostType_Footer::init();
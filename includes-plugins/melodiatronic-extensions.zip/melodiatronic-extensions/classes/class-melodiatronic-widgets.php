<?php
/**
 * widget base for Melodiatronic Extensions
 *
 * @package    melodiatronic-extensions
 * @author     Ibnu Sina
 * @license    GNU General Public License, version 3
 * @copyright  2023 Melodiatronic Extensions
 */

abstract class Melodiatronic_Widget extends WP_Widget {
	
	public $template;
	abstract function getTemplate();

	public function display( $args, $instance ) {
		$this->getTemplate();
		extract($args);
		extract($instance);
		echo $before_widget;
			require melodiatronic_elementor_get_widget_locate( $this->template );
		echo $after_widget;
	}
}
<?php
/**
 * Melodiatronic Extensions Plugin
 *
 * A simple, truly extensible and fully responsive options framework
 * for WordPress themes and plugins. Developed with WordPress coding
 * standards and PHP best practices in mind.
 *
 * Plugin Name:     Melodiatronic Extensions
 * Description:     Melodiatronic Extensions is a plugin required to activate the functionality in the Melodiatronic theme.
 * Author:          Ibnu Sina
 * Version:         1.1.10
 * Text Domain:     melodiatronic-extensions
 * License:         GPL3+
 * License URI:     http://www.gnu.org/licenses/gpl-3.0.txt
 * Domain Path:     languages
 */

define( 'MELODIATRONIC_ELEMENTOR_VERSION', '1.1.10');
define( 'MELODIATRONIC_ELEMENTOR_URL', plugin_dir_url( __FILE__ ) ); 
define( 'MELODIATRONIC_ELEMENTOR_DIR', plugin_dir_path( __FILE__ ) );

define( 'MELODIATRONIC_ELEMENTOR_ACTIVED', true );

include_once( ABSPATH . 'wp-admin/includes/plugin.php' );

require_once( MELODIATRONIC_ELEMENTOR_DIR . 'plugin-update-checker/plugin-update-checker.php' );
$myUpdateChecker = Puc_v4_Factory::buildUpdateChecker(
	'https://melodiatronic.github.io/update/melodiatronic-extensions/plugin.json',
	__FILE__, //Full path to the main plugin file or functions.php.
	'melodiatronic-extensions'
);

/**
 * Custom Post type
 *
 */
add_action( 'init', 'melodiatronic_elementor_register_post_types', 1 );

/**
 * functions
 *
 */
require MELODIATRONIC_ELEMENTOR_DIR . 'functions.php';
require MELODIATRONIC_ELEMENTOR_DIR . 'functions-preset.php';
/**
 * Widgets Core
 *
 */
require MELODIATRONIC_ELEMENTOR_DIR . 'classes/class-melodiatronic-widgets.php';
add_action( 'widgets_init',  'melodiatronic_elementor_widget_init' );

require MELODIATRONIC_ELEMENTOR_DIR . 'classes/class-melodiatronic-megamenu.php';
/**
 * Init
 *
 */
function melodiatronic_elementor_init() {
	$demo_mode = apply_filters( 'melodiatronic_elementor_register_demo_mode', false );
	if ( $demo_mode ) {
		melodiatronic_elementor_init_redux();
	}
	$enable_tax_fields = apply_filters( 'melodiatronic_elementor_enable_tax_fields', false );
	if ( $enable_tax_fields ) {
		if ( !class_exists( 'Taxonomy_MetaData_CMB2' ) ) {
			require_once MELODIATRONIC_ELEMENTOR_DIR . 'libs/cmb2/taxonomy/Taxonomy_MetaData_CMB2.php';
		}
	}
}
add_action( 'init', 'melodiatronic_elementor_init', 100 );
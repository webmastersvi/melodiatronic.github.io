jQuery(document).ready(function($){
    var source = '';
    var title = '';
    
    if ( $('.melodiatronic-btn-import').data('disabled') ) {
        $(this).attr('disabled', 'disabled');
    }
    
    $('.melodiatronic-btn-import').click(function(event){
        // all
        source = $(event.currentTarget).children("input").val();
        title = $(event.currentTarget).prev().text();
        if ( confirm('Import all data of skin "'+ title +'" and set "' + title + '" as default') ) {
            
            melodiatronic_open_popup();  
            
            $('.melodiatronic_progress_import_2').hide();
            $('.melodiatronic_progress_import_1').show();

            $(this).attr('disabled', 'disabled');
            $('.melodiatronic-progress-content').show();
            
            $('.first_settings span').hide();
            $('.first_settings .installing').show();
            $('.steps li').removeClass('active');
            $('.first_settings').addClass('active');

            melodiatronic_import_type('first_settings');
        }
    });     

    $('.melodiatronic-btn-config').click(function(event){ 
        // all
        source = $(event.currentTarget).children("input").val();
        title = $(event.currentTarget).prev().prev().text();
        if ( confirm('Only active skin and set  "' + title + '" as default (not import all data). You will lose all custom CSS in the options theme.') ) {
            
			melodiatronic_open_popup();	
			
            $('.melodiatronic-complete1').hide();
            $('.melodiatronic_progress_import_1').hide();
            $('.melodiatronic_progress_import_2').show();

            $(this).attr('disabled', 'disabled');
            $('.melodiatronic-progress-content').show();
            
            $('.first_settings span').hide();
            $('.first_settings .installing').show();
            $('.steps2 li').removeClass('active');
            $('.first_settings').addClass('active');

            melodiatronic_import_type2('first_settings2');
        }
    }); 
	
	$('.melodiatronic-close-import-popup').click(function(event){
        melodiatronic_close_popup();
    });

    function melodiatronic_import_type( type ) {
        $.ajax({
            type: 'POST',
            url: ajaxurl,
            data: {
                action: 'melodiatronic_import_sample',
                demo_source: source,
                ajax: 1, 
                import_type: type
            },
            dataType: 'json',
            success: function (res) {
                var next = res.next;

                if ( res.status == false ) {
                    melodiatronic_import_error( res );
                    return false;
                }

                if ( next == 'done' ) {
                    melodiatronic_import_complete( type );
                    $('.melodiatronic-close-import-popup').show();
                    return false;
                }
                
                if ( next == 'error' ) {
                    melodiatronic_import_error( res );
                    $('.melodiatronic-close-import-popup').show();
                    return false;
                }

                melodiatronic_import_complete_step( type, res );
                melodiatronic_import_type( next );
                
            },
            error: function (html) {
                $('.melodiatronic_progress_error_message .melodiatronic-error .content').append('<p>' + html + '</p>');
                $('.melodiatronic_progress_error_message').show();
                return false;
            }
        });

        return false;
    }

    function melodiatronic_import_type2( type ) {
        $.ajax({
            type: 'POST',
            url: ajaxurl,
            data: {
                action: 'melodiatronic_import_sample',
                demo_source: source,
                ajax: 1, 
                import_type: type
            },
            dataType: 'json',
            success: function (res) {
                var next = res.next;

                if ( res.status == false ) {
                    melodiatronic_import_error( res );
                    return false;
                }

                if ( next == 'done' ) {
                    melodiatronic_import_complete2( type );
					$('.melodiatronic-close-import-popup').show();
                    return false;
                }
                
                if ( next == 'error' ) {
                    melodiatronic_import_error( res );
					$('.melodiatronic-close-import-popup').show();
                    return false;
                }

                melodiatronic_import_complete_step2( type, res );
                melodiatronic_import_type2( next );
				
            },
            error: function (html) {
                $('.melodiatronic_progress_error_message .melodiatronic-error .content').append('<p>' + html + '</p>');
                $('.melodiatronic_progress_error_message').show();
                return false;
            }
        });

        return false;
    }

    function melodiatronic_import_complete_step(type, res) {
        $( '.' + type + ' span' ).hide();
        $( '.' + type + ' .installed' ).show();

        var next = res.next;
        if ( next == 'done' ) {
            $('.melodiatronic-complete1').show();
            $('.steps li').removeClass('active');
            $('.melodiatronic-btn-import').removeAttr('disabled');
        } else {
            $('.' + next + ' span').hide();
            $('.' + next + ' .installing').show();
            $('.steps li').removeClass('active');
            $('.' + next).addClass('active');
        }
    }

    function melodiatronic_import_complete_step2(type, res) {
        $( '.' + type + ' span' ).hide();
        $( '.' + type + ' .installed' ).show();

        var next = res.next;
        if ( next == 'done' ) {
            $('.melodiatronic-complete2').show();
            $('.steps li').removeClass('active');
            $('.melodiatronic-btn-import').removeAttr('disabled');
        } else {
            $('.' + next + ' span').hide();
            $('.' + next + ' .installing').show();
            $('.steps li').removeClass('active');
            $('.' + next).addClass('active');
        }
    }

    function melodiatronic_import_complete(type) {
        $( '.' + type + ' span' ).hide();
        $( '.' + type + ' .installed' ).show();
        $('.melodiatronic-complete1').show();
        $('.melodiatronic-btn-import').removeAttr('disabled');
    }    

    function melodiatronic_import_complete2(type) {
        $( '.' + type + ' span' ).hide();
        $( '.' + type + ' .installed' ).show();
        $('.melodiatronic-complete2').show();
        $('.melodiatronic-btn-import').removeAttr('disabled');
        location.reload();
    }

    function melodiatronic_import_error(res) {
        if ( res.msg !== undefined && res.msg != '' ) {
            $('.melodiatronic_progress_error_message .melodiatronic-error .content').append('<p>' + res.msg + '</p>');
            $('.melodiatronic_progress_error_message').show();
        }
    }
	
	function melodiatronic_open_popup() {
        var $body = $('body');
        $body.addClass('open-popup'); 
        $body.append('<div id="TB_overlay" class="TB_overlayBG"></div>');

		$('.melodiatronic-popup').show(); 
        $('.melodiatronic-popup').animate({
            'top': '50%'
        }, 1000);
    }	
	
	function melodiatronic_close_popup() {
        var $body = $('body');
        $body.removeClass('open-popup'); 
        $('#TB_overlay').remove();

        $('.melodiatronic-popup').hide();
    }

});


